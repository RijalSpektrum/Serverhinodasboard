module.exports = {
    'secret':'rahasiaku',
}
console.log(module.exports);